#include <cstdlib>
#include <iostream>
#include <fstream>
/*- O data nestatica are rezervata zona de memorie disticta in fiecare obiect
  - O data nestatica are rezervata o zona de memorie UNICA pentru TOATE obiectele; 
  	Zona de memorie trebuie rezervata INAINTE de creerea obiectelor= dupa declararea clasei (inainte de main); 
  	Rezervarea se face prin DECLARAREA datei statice; 
  	IMPLICIT primeste valoarea 0 (ca orice variabila globala);
 	Permite si INITIALIZAREA cu alte valori (DOAR la declarare nu tine cont de tipul de acces)  
  - Data statica poate fi accesata printr-un obiect(obiect.varStatica) sau prin clasa (clasa::varStatica)
  - O metoda nestatica are pointerul this (adresa obiectului implicit)
  - O metoda statica NU ARE POINTERUL THIS -> nu poate accesa decat date statice 
	Metoda statica poate fi apelata prin obiect (obiect.metodaStatica(..);) sau prin clasa (clasa::metodaStatica(..);)
*/
using namespace std;
class C
{static  int s;
 int ns;
public:
C(){s=-1;}
void fns(){ns=2; //(*this).ns=2; 
           s=2; (*this).s=2;C::s=2;
           }
static void fs(){ // nu exista this
    //ns=1; // ns este (*this).ns ;nu exista this->nu avem obiect pt ns 
    // fns(); // fns() este (*this).f();nu exista this->nu am obiect care sa apeleze fns()    
                 cout<<s<<C::s<<endl;
                 C oc; oc.ns=-1; // pot accesa datele nestatice ale unui Obiect al clasei
                }

 } o1;

//int C::s;// trebuie redeclarat pt a aloca zona de memorie
            //daca nu se initializeaza are val 0 (ca variabilele globale)
            // se aloca inainte de creerea obiectelor- chiar si inainte de o1!!!
int C::s=1;// la declarare se poate si initializa desi nu este accesibil (e privat) !!


int main()
{C::fs(); /* folosit de obicei pentru initializarea datelor statice */
 C o2;
 o2.fs();
//C::s=2; //!!! EROARE- data privata -aici nu este accesibila
}
/* -datele stice =date comune tuturor obiectelor ANALOG variabilelor globale (SCOPUL: de a tine locul variabilelor globale!!)
   -avantaj: datele statice sunt protejate si sunt incapsulate in clasa (sunt modificate prin metode-preferabile variabilelor globale)
   -pot avea date statice si const initializate sau la declarare sau la redefinire- rol de constanta a clasei
   -o singura zona de memorie pentru toate obiectele clasei si ale claselor derivate !!! 
*/
