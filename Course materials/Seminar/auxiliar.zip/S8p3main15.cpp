#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;
///int & f(int x[])
int & f(int x[5])
///int & f(int *x)
{x[1]=10;
 return *x;
 }
 int main()
 {int a[5];
  for(int i=0;i<5;i++) a[i]=i;
  f(a)=7;
  for(int i=0;i<5;i++) cout<<a[i];
  return 0;
 }
