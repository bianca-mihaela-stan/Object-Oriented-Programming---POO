#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;
class B
{int i;
 public: B(int x=1){i=x;}
};
class A
{int w;
 B b;
public: A(int i):b(i-1){w=i;}
A(const A & o){}
};
class D: public A, B
{public: D(int i):B(i),A(i){}
};
void f(D ob){}
int main()
{A a(1);//B(0),A(1)
 B b;//B(1)
 D d(3);//B(2)A(3)B(3)D(3)
 f(d);

 ///v1. B( B&),A(A&),B(B&), D(D&)
///v2. B(1)A(A&), B(B&), D(D&)
}

