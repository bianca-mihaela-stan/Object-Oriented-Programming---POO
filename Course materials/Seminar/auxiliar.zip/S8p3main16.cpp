#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;
int mister(int a)
{int m,n;
if (a<=1) return 1;
else {cout<<a+3;
      m=a+3;
      n=mister(a-1)+mister(a-2);
       cout<<m+n;
       return n;}
}

int main()
{int i;
cout<<mister(5);
return 0;
}
