#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;
class single
{single(){}
 single(const single &){}
 static single * pOb1;
 //static single ob1;
 public :
 static single * creereOb()
 { if (!pOb1) pOb1=new single();
   return pOb1;
 };
 single * single::pOb1=nullptr;
int main()
{ ///single o1,o2,o3;
   single *pO;
   pO=single::creereOb();
}

class singleL
{singleL(){}
 singleL(const singleL &){}
 ///static single * pOb1;
 public :
 static singleL * creereOb()
 { static singleL * pOb1=nullptr;
   if (!pOb1) pOb1=new singleL();
          return pOb1;
 };
 single * single::pOb1=nullptr;
int main()
{ //single o1,o2,o3;
   single *pO;
   pO=single::creereOb();
}
