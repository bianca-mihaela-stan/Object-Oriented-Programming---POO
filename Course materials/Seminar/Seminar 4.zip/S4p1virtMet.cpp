#include <cstdlib>
#include <iostream>
/*Metode virtuale */

/* -Orice clasa care are metode virtuale are construita o tabela cu metodele virtuale
  - Orice obiect dintr-o clasa cu metode virtuale are in plus un pointer suplimentar catre tabela cu metode virtuale
  - Metodele NEVIRTUALE se EVALUEAZA LA COMPILARE 
  - Metodele VIRTUALE se EVALUEAZA LA EXECUTIE prin intermediul POINERULUI SUPLIMENTAR atasat obiectului.
  */
using namespace std;
class B
{ public:
       void fnv(){cout<<"B nevirttuala\n";} /* evaluare la compilare*/
       virtual void fv(){cout<<"B virtuala\n";}/*evaluare la executie-obiectul are un pointer suplimentar
                                                catre tabela cu metode virtuale*/
       void fB(){fnv();fv();} /* evaluare la compilare a fnv din B,  evaluare la executie a fv din D prin pointerul suplimentar*/
};

class D: public B
{ public:
        void fnv(){cout<<"D nevirtuala\n";}
        void fv(){cout<<"D virtuala\n";}    /*-ramane virtuala daca are acelasi tip intors si aceiasi parametrii 
										    - exceptie : tipul intors poate fi pointer la Baza si respectiv la Derivata*/
        void fs(){cout<<"f suplimentara\n";}

};

void fGeneralaRef(B &rb) /* va putea fi apelata cu obiecte din B sau D  */
{rb.fnv();/* alege la compilare fnv din B  */
 rb.fv();/* alege la executie corespunzator clasei obiectului (B sau D) */
}

void fGeneralaPtr(B *pb) /* va putea fi apelata cu adrese de obiecte din B sau D*/
{pb->fnv();/* alege la compilare fnv din B */
 pb->fv();/* alege la executie corespunzator clasei obiectului (B sau D) */
}

int main(int argc, char *argv[])
{B b;
 D d;
 d.fnv();// evaluare la compilare alege fnv din D
 d.fv();// evaluare la executie alege fv din D

/* Apel prin pointer la baza */
B *pb=&d; // in pointer la BAZA pot pune adresa unui obiect din DERIVATA
/* pb->fs();  pb nu vede decat membrii din clasa B -fs nu e vizibil prin  pointerul pb -vede de la inceputul obiectului 
              doar un nr de octeti (dimensiunea unui obiect din B)  */
pb->fnv(); /*alege la compilare fnv din B*/
pb->fv(); /* alege la executie fv din D*/

/* apel prin referinta la baza*/
B &rb=d; /* referinta la BAZA poate referi un obiect din DERIVATA (e alt nume pentru partea de baza a obiectului din derivata)*/
/* rb.fs();  rb nu vede decat membrii din clasa B -fs nu e vizibil prin  referinta rb */
rb.fnv(); /*alege la compilare fnv din  B*/
rb.fv(); /* alege la executie fv din D*/


B *v[2]; /*pot avea  vector de pointeri la BAZA ce contine adrese de obiecte de tipuri diferite */
v[0]=new B;
v[1]=new D ; 
for(int i=0;i<2;i++)
{v[i]->fnv();  /*alege la compilare fnv din B */
 v[i]->fv();   /* alege la executie fv() din clasa corespunzatoare  obiectului (B sau D)*/
}

fGeneralaRef(b); /* alege fv din B */
fGeneralaRef(d);  /* alege fv din D */

fGeneralaPtr(&b); /* alege fv din B */
fGeneralaPtr(&d); /* alege fv din D */

/*Metoda din B are pointerul this = pointer la B */
d.fB() ; // apeleaza fnv din B -evaluare la compilare dar fv din D -evaluare la executie
pb->fB(); /* alege la compilare fnv(din B), alege la  executie   fv (din D)*/
rb.fB(); /* alege la compilare fnv (din B), alege la  executie   fv (din D)*/
   return 0;
}
