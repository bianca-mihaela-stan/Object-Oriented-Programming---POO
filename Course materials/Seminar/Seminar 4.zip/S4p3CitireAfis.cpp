// Citire   si scriere pentru ierarhie de clase cu metode virtuale
#include <cstdlib>
#include <iostream>
#include <fstream>
using namespace std;
/*- Se poate declara  operatorul >> DOAR pt baza, si va  fi apelat si pentru derivata;
    operatorul va apela prin referinta la baza, o metoda VIRTUALA de citire-> se va evalua la executie
   ->se alege functia citire a clasei din care face parte obiectul (la fel si pentru afisare)
*/

class B
{int i;
 public:
 virtual void citire(istream & si){cout<<"citire B"<<endl; si>>i;}
 virtual void afisare(ostream & so)const {cout<<"afisare B"<<endl; so<<i;}
};

class D: public B
{int s;
 public:
 void citire(istream &si)
     {B::citire(si);
      cout<<" citire D"<<endl;
      si>>s;
      }
void afisare(ostream &so)
     {B::afisare(so);
      cout<<" afisare D"<<endl;
      so<<s;
      }
};

istream & operator >>(istream & si,B& ob) /* nu e nevoie sa fie friend-apeleaza citire - o functie publica  */
{ob.citire(si);return si;} /* se va evalua la executie -> se executa citire pentru clasa din care face parte obiectul (B sau D) */
ostream & operator <<(ostream & so,const B& ob)
{ob.afisare(so);return so;}

int main()
{   D d;
	B b;
    ifstream f("t.txt");
	cin>>b;cout<<b;
	cin>>d; cout<<d;/* in operatorul >>, functia citire se evalueaza la executie -se alege citire din D */
	f>>d; /* functioneaza si pt fisiere - pentru ca ifstream deriva din istream iar parametrul e REFERINTA la baza (istream &) */
    return 0;
}
