/* exemplu care calculeaza volumul prismelor de tip cilindru, paralelipiped dreptunghic si cub*/
#include <cstdlib>
#include <iostream>
using namespace std;
class prisma
{protected:double h; /* necesar in clasa cub */
 public: prisma(int ph=0){h=ph;}
 virtual double arie()=0;/*- nu se stie o formula a ariei-> metoda virtuala pura ->necesita redefinire in clasele derivate
						   - nu pot declara obiect de tip prisma, dar pot declara referinta si pointer de tip prisma*/
 double volum(){return h*arie();} /* formula volumului depinde de arie, nu si de forma bazei */ 
};

class cilindru: public prisma /* cilindrul ESTE o prisma cu baza cerc */
{double r;
public: cilindru(double ph,double pr):prisma(ph){r=pr;}
       double arie(){return 3.14*r*r;} 
};

class ppd: public prisma /*paralelipipedul dreptunghic ESTE o prisma cu baza dreptunghi*/
{double l,L;
 public: ppd(double ph,double pl,double pL):prisma(ph){l=pl;L=pL;}
         double arie(){return l*L;}
};

class cub:public prisma
{public: cub(double ph):prisma(ph){};/* daca nu se apeleaza explicit constructorul bazei cu parametru, se va apela
                                        implicit constructorul bazei fara parametru*/
         double arie(){return h*h;}/* am nevoie de h deci necesar ca protected in prisma*/
};

int main(int argc, char *argv[])
{  cilindru c1(5,5);
   c1.arie(); 
   c1.volum(); 

   prisma * vp[10]; /* colectie de adrese de prisme diferite*/
   vp[0]=new cilindru(5,5);
   vp[1]=new ppd(5,5,5);
   vp[2]=new cub(5);

   for (int i=0;i<3;i++) cout<<(vp[i]->arie())<<(vp[i]->volum());
   return 0;
}



