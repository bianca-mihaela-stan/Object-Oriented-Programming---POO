/* mostenirea multipla virtuala */
#include <iostream>
#include <cstring>
/* -mostenirea virtuala a unei clase A, prin intermediul a doua clase derivate B si C presupune ca 
    in clasa D derivata din B si C exista un obiect din B si un obiect din C care au in COMUN UN OBIECT DIN A
  - ex: in clasa D exista o SINGURA DATA (int a) COMUNA obiectului din clasa B si obiectului din clasa C 
  - daca mostenirea nu ar fi virtuala, in D as avea 2 date (int a) DISTINCTE pentru obiectele din clasele B si C;    
*/
using namespace std;
class A
{int a;
 public: A(int i=0){cout<<"A"<<i<<" "<<endl;}   
};

class B: virtual public A
{int b;
 public: B():A(1){};   
};

class C: virtual public A
{int c;
 public: C():A(2){}  
};

class E{public: E(){cout<<"E"<<endl;}};

class D:public E,public B,public C /* IMPLICIT se apeleaza constructorul implicit al clasei A -fara parametrii
                                      se poate apela si EXPLICIT constructorul clasei A -transmit parametrii */
{public : D():A(3){} };  /* -se apeleaza constructorul implicit ( A()) sau explicit (A(3)) o SINGURA DATA pentru UNICA data membra din clasa A 
                            - constructorul din A se va apela PRIMUL, chiar si inaintea constructorului din E ; 
                            -UNICUL obiect din A va fi folosit in COMUN de  constructorii claselor B si C pentru a crea cele 2 obiecte. */
int main()
{ D d;
  return 0;
}
